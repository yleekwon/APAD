# Copyright 2018 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START gae_python37_cloudsql_mysql]
import os

from flask import Flask,render_template,request
import pymysql

db_user = os.environ.get('CLOUD_SQL_USERNAME')
db_password = os.environ.get('CLOUD_SQL_PASSWORD')
db_name = os.environ.get('CLOUD_SQL_DATABASE_NAME')
db_connection_name = os.environ.get('CLOUD_SQL_CONNECTION_NAME')

app = Flask(__name__)


## LOGIN - FORM
@app.route('/')
def login():
    return render_template('login.html')

## Once logged in, takes you to the index page with the welcome message
## LOGIN - FORM SUBMISSION

@app.route('/login_index', methods=['POST'])
def login_index():
    myEmail = request.form['email']
    myEID = request.form['EID']
    
    if os.environ.get('GAE_ENV') == 'standard':
        # If deployed, use the local socket interface for accessing Cloud SQL
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
    with cnx.cursor() as cursor:
        userCheck = cursor.execute('SELECT * FROM users WHERE EID = %s AND email = %s', (myEID, myEmail))
        entry = cursor.fetchall()
        num = list(entry)
        if len(num)==0:
            error = 'Invalid credentials'
            return render_template('login.html', error=error)
        else:
            myAdmin=0
            for element in num:
                if element[5]==1:
                    myAdmin=1
                    break
            error = None
    
    cnx.commit()
    return render_template('login_index.html', admin = myAdmin)

    

@app.route('/adduser')
def main1():

    return render_template('user_form.html')
# def adduser(EID_admin, name, phone, email, EID, admin):
#     ## Grabs the row of information that connects to the user_id
#     adminCheck = cursor.execute('SELECT * FROM users WHERE EID = ? ', (EID_admin,))
#     entry = cursor.fetchone()

#     ## Checking that the user is an admin
#     if entry[5] == 1: 
#         sql = "INSERT INTO users(name, phone, email, EID, admin) VALUES(?, ?, ?, ?, ?)"
#         cursor.execute(sql, (name, phone, email, EID, admin))
#         db.commit()
#         return('New user added')
#     else:
#         raise Exception('ERROR: Not an admin') 

@app.route('/usersubmitted', methods=['POST'])
def submitted_form():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    EID = request.form['EID']
    admin = request.form['admin']

    if len(EID) != 7:
        return ("INVALID EID. PLEASE TRY AGAIN!")
    else:
        if os.environ.get('GAE_ENV') == 'standard':
            # If deployed, use the local socket interface for accessing Cloud SQL
            unix_socket = '/cloudsql/{}'.format(db_connection_name)
            cnx = pymysql.connect(user=db_user, password=db_password,
                                  unix_socket=unix_socket, db=db_name)
        else:
            # If running locally, use the TCP connections instead
            # Set up Cloud SQL Proxy (cloud.google.com/sql/docs/mysql/sql-proxy)
            # so that your application can use 127.0.0.1:3306 to connect to your
            # Cloud SQL instance
            host = '127.0.0.1'
            cnx = pymysql.connect(user=db_user, password=db_password,
                                  host=host, db=db_name)

        with cnx.cursor() as cursor:
            cursor.execute('INSERT INTO users (name, phone, email, EID, admin) VALUES(%s, %s, %s, %s, %s)' , (name, phone, email, EID, admin))
            #rows = cursor.fetchall()
        cnx.commit()

        return render_template(
        'user_submitted_form.html',
        name=name,
        email=email,
        phone=phone,
        EID=EID,
        admin=admin)


@app.route('/addvenue')
def main2():
    if os.environ.get('GAE_ENV') == 'standard':
        # If deployed, use the local socket interface for accessing Cloud SQL
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
    else:
        # If running locally, use the TCP connections instead
        # Set up Cloud SQL Proxy (cloud.google.com/sql/docs/mysql/sql-proxy)
        # so that your application can use 127.0.0.1:3306 to connect to your
        # Cloud SQL instance
        host = '127.0.0.1'
        cnx = pymysql.connect(user=db_user, password=db_password,
                              host=host, db=db_name)

    with cnx.cursor() as cursor:
        cursor.execute('SELECT * from venues;')
        rows = cursor.fetchall()

        for row in rows:
            return("{0} {1} {2}.{3}".format(row[0], row[1], row[2], row[3]))
    cnx.close()


@app.route('/addevent')
def main3():
    return ('Help Me')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)