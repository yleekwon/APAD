# Copyright 2018 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START gae_python37_cloudsql_mysql]
import os

from flask import Flask,render_template,request, flash
import pymysql

db_user = os.environ.get('CLOUD_SQL_USERNAME')
db_password = os.environ.get('CLOUD_SQL_PASSWORD')
db_name = os.environ.get('CLOUD_SQL_DATABASE_NAME')
db_connection_name = os.environ.get('CLOUD_SQL_CONNECTION_NAME')

app = Flask(__name__)


## LOGIN - FORM
@app.route('/')
def login():
    return render_template('login_index.html')

## Once logged in, takes you to the index page with the welcome message
## LOGIN - FORM SUBMISSION

@app.route('/login_index', methods=['POST'])
def login_yes():
    myEmail = request.form['email']
    myEID = request.form['EID']
    
    if os.environ.get('GAE_ENV') == 'standard':
        # If deployed, use the local socket interface for accessing Cloud SQL
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
    with cnx.cursor() as cursor:
        userCheck = cursor.execute('SELECT * FROM users WHERE EID = %s AND email = %s', (myEmail, MyEID))
        entry = cursor.fetchone()

        myAdmin = entry[5]
        error = None
        
        if entry IS NOT NULL:
            flash('You were successfully logged in')
        else:
            error = 'Invalid credentials'
            return render_template('login')
    
    cnx.commit()
    return render_template('login_index.html', admin = myAdmin)

    

## ADD USER - FORM 
@app.route('/adduser')
def main1():
    return render_template('user_form.html')

## ADD USER - SUBMIITED 
@app.route('/usersubmitted', methods=['POST'])
def submitted_form():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    EID = request.form['EID']
    admin = request.form['admin']

    if os.environ.get('GAE_ENV') == 'standard':
        # If deployed, use the local socket interface for accessing Cloud SQL
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
    with cnx.cursor() as cursor:
        cursor.execute('INSERT INTO users (name, phone, email, EID, admin) VALUES(%s, %s, %s, %s, %s)' , (name, phone, email, EID, admin))
        #rows = cursor.fetchall()
    cnx.commit()

    return render_template(
    'user_submitted_form.html',
    name=name,
    email=email,
    phone=phone,
    EID=EID,
    admin=admin)


@app.route('/addvenue')
def main2():
    if os.environ.get('GAE_ENV') == 'standard':
        # If deployed, use the local socket interface for accessing Cloud SQL
        unix_socket = '/cloudsql/{}'.format(db_connection_name)
        cnx = pymysql.connect(user=db_user, password=db_password,
                              unix_socket=unix_socket, db=db_name)
    with cnx.cursor() as cursor:
        cursor.execute('SELECT * from venues;')
        rows = cursor.fetchall()

        for row in rows:
            return("{0} {1} {2}.{3}".format(row[0], row[1], row[2], row[3]))
    cnx.close()


@app.route('/addevent')
def main3():
    return ('Help Me')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)